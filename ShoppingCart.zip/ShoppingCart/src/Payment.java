public enum Payment {
	FIXED_AMOUNT, PER_HOUR 
}
